leaflet-map-template
====================

Includes HTML, CSS, and geoJSON template for making a Leaflet.js map.
